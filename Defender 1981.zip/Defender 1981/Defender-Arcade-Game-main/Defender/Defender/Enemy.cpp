﻿#include "Enemy.h"
#include "Glut.h"
#include <math.h>
#include "Bullet.h"


#define PI 3.14159

Enemy::Enemy() {
    alive = false;
}

Enemy::Enemy(double PosX, double PosY, double r, double s) {
    enemyPosX = PosX;
    enemyPosY = PosY;
    radius = r;
    speed = s;
    alive = true;
    direction = 1;
}

void Enemy::drawEnemy() {
    glBegin(GL_POLYGON);
    glColor3f(0, 1, 0);
    double x, y, angle;

    for (int i = 0; i < 20; i++) {
        angle = 2.0 * PI * i / 20;
        x = enemyPosX + radius * cos(angle);
        y = enemyPosY + radius * sin(angle);
        glVertex2f(x, y);
    }

    glEnd();
}

void Enemy::drawEnemy1() {
    glBegin(GL_POLYGON);
    glColor3f(0, 1, 1);
    double x, y, angle;

    for (int i = 0; i < 20; i++) {
        angle = 2.0 * PI * i / 20;
        x = enemyPosX + radius * cos(angle);
        y = enemyPosY + radius * sin(angle);
        glVertex2f(x, y);
    }

    glEnd();
}

void Enemy::drawEnemy2() {
    glBegin(GL_POLYGON);
    glColor3f(1, 1, 0);
    double x, y, angle;

    for (int i = 0; i < 20; i++) {
        angle = 2.0 * PI * i / 20;
        x = enemyPosX + radius * cos(angle);
        y = enemyPosY + radius * sin(angle);
        glVertex2f(x, y);
    }

    glEnd();
}

void Enemy::moveEnemy() {
    enemyPosX += direction == 1 ? speed : -speed;

    if (enemyPosX + radius >= 800) {
        direction = 0;
    }
    else if (enemyPosX - radius <= 0) {
        direction = 1;
    }
}

void Enemy::moveEnemy1() {
    moveEnemy();
}

void Enemy::moveEnemy2() {
    moveEnemy();
}

bool Enemy::isAlive() {
    return alive;
}

bool collision(double x1, double y1, double r1, double x2, double y2, double r2) {
    double d = sqrtf((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    return d <= r1 + r2;
}

bool Enemy::bulletCollision(Bullet bullet) {
    return collision(bullet.posBulletX, bullet.posBulletY, bullet.radius,
        enemyPosX, enemyPosY, radius);
}

bool Enemy::bulletCollision1(Bullet bullet) {
    return bulletCollision(bullet);
}

bool Enemy::bulletCollision2(Bullet bullet) {
    return bulletCollision(bullet);
}

bool Enemy::shipCollision(Ship ship) {
    return collision(ship.posShipX, ship.posShipY, 8, enemyPosX, enemyPosY, radius);
}

bool Enemy::shipCollision1(Ship ship) {
    return shipCollision(ship);
}

bool Enemy::shipCollision2(Ship ship) {
    return shipCollision(ship);
}
