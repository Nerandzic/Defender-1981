#pragma once

class Legend {

public:
	int score;
	int lives;
	int level;

	Legend();

	void drawLegend();
	void drawScore();
};